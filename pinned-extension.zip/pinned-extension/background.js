import { Tracker, ReminderService, BadgeManager } from './core.js';

const tracker = Tracker.create();
const reminders = new ReminderService();
const badge = new BadgeManager();

// The worker can be shut down at any time, so nothing is kept in memory.
// Everything is rebuilt from storage whenever it wakes up.
async function refresh() {
  const items = await tracker.service.list();
  await reminders.sync(items);
  await badge.update(items);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('refresh', { periodInMinutes: 60 });
  refresh();
});

chrome.runtime.onStartup.addListener(refresh);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.assessments) refresh();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'refresh') return refresh();
  if (!alarm.name.startsWith(ReminderService.PREFIX)) return;

  const [, id, key] = alarm.name.split('|');
  const item = (await tracker.service.list()).find((i) => i.id === id);
  if (!item || item.isPast()) return;

  const offset = item.reminderOffsets().find((o) => o.key === key);
  const open = item.openSteps().length;
  chrome.notifications.create(alarm.name, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: `${item.course}: ${item.title}`,
    message: `${item.kind} ${offset?.phrase ?? 'is coming up'}.${open ? ` ${open} step${open === 1 ? '' : 's'} still to tick off.` : ''}`,
  });
});

chrome.notifications.onClicked.addListener((id) => {
  chrome.tabs.create({ url: chrome.runtime.getURL('board.html') });
  chrome.notifications.clear(id);
});
