import { Tracker, ValidationError } from './core.js';
import { el, NoteRenderer, Toast, toLocalInput } from './ui.js';

const tracker = Tracker.create();
const $ = (id) => document.getElementById(id);
const toast = new Toast($('toast'));
const SHOW = 3;

const renderer = new NoteRenderer({
  toggle: async (itemId, stepId, li) => {
    li.classList.toggle('done'); // answers the tap straight away; the list redraws after storage settles
    await tracker.service.toggleStep(itemId, stepId);
  },
}, { compact: true });

async function render() {
  const now = new Date();
  const all = await tracker.service.list();
  const upcoming = all.filter((i) => i.hasValidDate && !i.isPast(now)).sort((a, b) => a.dueDate - b.dueDate);

  const week = upcoming.filter((i) => i.daysLeft(now) <= 7).length;
  $('lede').textContent = upcoming.length === 0
    ? 'Nothing pinned yet. Stick your first note up.'
    : week === 0
      ? `Nothing due this week. Next is ${upcoming[0].title}, ${upcoming[0].countdownLabel(now)}.`
      : `${week} due in the next 7 days.`;

  $('list').replaceChildren(...upcoming.slice(0, SHOW).map((i) => renderer.render(i)));
  const rest = upcoming.length - SHOW;
  $('more').hidden = rest <= 0;
  if (rest > 0) $('more').textContent = `plus ${rest} more on the board`;

  $('courses').replaceChildren(...[...new Set(all.map((i) => i.course))].map((c) => el('option', { value: c })));
}

$('pin').addEventListener('click', () => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(9, 0, 0, 0);
  $('quick').elements.due.value = toLocalInput(d);
  $('quick').hidden = false;
  $('pin').hidden = true;
  $('quick').elements.course.focus();
});

$('cancel').addEventListener('click', () => {
  $('quick').hidden = true;
  $('pin').hidden = false;
});

$('quick').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.currentTarget.elements;
  try {
    await tracker.service.add({ kind: f.kind.value, course: f.course.value, title: f.title.value, due: f.due.value });
    e.currentTarget.reset();
    $('err').textContent = '';
    $('quick').hidden = true;
    $('pin').hidden = false;
    await render();
    toast.show('Pinned. Add steps and photos on the board.');
  } catch (err) {
    if (!(err instanceof ValidationError)) throw err;
    $('err').textContent = err.message;
  }
});

let timer;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.assessments) {
    clearTimeout(timer);
    timer = setTimeout(render, 450);
  }
});

render();
