Pinned: Chrome extension
1. Unzip this folder.
2. In Chrome open chrome://extensions and switch on Developer mode (top right).
3. Click "Load unpacked" and choose the unzipped "pinned-extension" folder.
4. Click the puzzle-piece icon in Chrome and pin "Pinned".
Notes are saved in this browser only and do not sync with the website account.
